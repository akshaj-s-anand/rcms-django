from django.contrib import admin
from home.models import Enquiry, ProductDetails

# Register your models here.

admin.site.register(Enquiry)
admin.site.register(ProductDetails)